# UAE Rent Prediction

This project aims to predict rental prices in the UAE using machine learning techniques.